<?php

require "Pessoa.php";

$uma_pessoa = new Pessoa("Ana");


echo $uma_pessoa->getNome();

